package org.keepcoding.dominio

case class Geolocalizacion(latitud: Double, longitud: Double, ciudad: String, pais: String)

case class Transaccion(DNI: Long, importe: Double, descripcion: String, categoria: String, tarjetaCredito: String, geolocalizacion: Geolocalizacion)

case class Cliente(DNI: Long, nombre:String, cuentaCorriente:String)